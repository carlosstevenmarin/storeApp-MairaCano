
package test;

public class TestGeneral {
    public static void main( String[ ] args ) 
   {
      TestCustomer tc = new TestCustomer();
      tc.listCustomer();
   }
}
